import nodemailer from "nodemailer"

import {config} from "dotenv"

config();

export const mailer = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    secure: false,
    auth: {
        user: "arpit8345@gmail.com",
        pass: "tozmvgowjbmofkxt"
    }
})

export  const sendMail = (to:string, subject:string, html:any) => {
    mailer.sendMail({
        from: "arpit8345@gmail.com",
        to: to,
        subject: subject,
        html:html
    })
}