import React from 'react'

const Home = () => {
  return (<>
      dipchip
    </>
  )
}

export default Home